// Need rollup-plugin-json for the following magic
export {version} from '../package.json';

export * from './index';
