
export class BadArgumentException extends Error { }
