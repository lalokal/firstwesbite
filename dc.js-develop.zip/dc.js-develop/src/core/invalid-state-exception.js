
export class InvalidStateException extends Error { }
